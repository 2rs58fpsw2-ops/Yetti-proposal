# YettiAir Complete Proposal v6

This version is designed as one connected proposal platform.

## Customer presentation
- Page 1: Budget / Good / Better / Best comparison
- Page 2: Budget detail
- Page 3: Good detail
- Page 4: Better detail
- Page 5: Best detail
- All pages are driven by the same editable proposal data.
- Print Proposal prints the full customer deck.

## Sales / admin controls
- Customer and proposal information
- Four equipment options
- Outdoor / indoor / furnace model numbers
- AHRI reference and certificate link
- Equipment image upload or URL
- Editable customer-facing feature bullets and “Best For” copy
- Equipment, labor, materials and other internal costs
- Target gross margin and Apply Target Margin Price
- Rep commission constrained to 8–12% and commission dollars
- Company gross after rep commission
- Utility instant rebate
- Electrification rebate
- Optional federal tax credit informational line
- Five editable discount lines
- Editable Tier 1 / 2 / 3 installation package wording
- Accessories / adders
- Standard installation scope
- Customer selection and acceptance
- Save / load draft and export proposal data

## Important
Verify AHRI qualification, utility incentives, electrification incentives, tax-credit eligibility, financing disclosures, warranty terms and maintenance-program requirements before presenting them as final contractual terms.
